from django.db import models
from enum import Enum
import numpy as np
import cv2
import sys
import random
# Create your models here.

class Player1(models.Model):
    name = models.CharField(max_length=255)
    right_answer = models.IntegerField
    wrong_answer = models.IntegerField

class Player2(models.Model):
    name = models.CharField(max_length=255)
    right_answer = models.IntegerField
    wrong_answer = models.IntegerField
